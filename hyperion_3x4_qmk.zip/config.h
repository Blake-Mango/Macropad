#pragma once

#include "config_common.h"

#define MATRIX_ROWS 3
#define MATRIX_COLS 4

#define MATRIX_ROW_PINS { GP0, GP1, GP2 }
#define MATRIX_COL_PINS { GP3, GP4, GP5, GP6 }

#define DIODE_DIRECTION ROW2COL

#define UNUSED_PINS
